library(shiny)
library(ggplot2)
library(dplyr)
ui <- fluidPage(
    titlePanel("Sociophonetic Variation in Barcelonan Spanish Lateral Production"),
    sidebarLayout(
        sidebarPanel(
          selectInput("SocialGroupInput", "SocialGroup",
                         choices = c("GroupA", "GroupB", "GroupC"),
                         selected = "GroupA",
                         multiple =TRUE),
          selectInput("GenderInput", "Gender",
                         choices = c("Male", "Female"),
                      selected="Male",
                         multiple =TRUE),
          selectInput("StyleInput", "Style",
                         choices = c("Casual", "Formal"),
                      selected = "Casual",
                          multiple =TRUE),
          radioButtons("GraphInput", "Graph Type",
                      choices = c("Bar", "Density"),
                      selected = "Bar")),

        
        mainPanel(
            plotOutput("plot1"))))

server <- function(input, output) {
    ModelName = readRDS("ModelName.rds")
    DataName = read.csv("JD_DATA.csv")

  output$plot1 <- renderPlot({
    if (input$GraphInput == "Bar") {
         displayData = DataName %>%
         filter(SocialGroup %in% input$SocialGroupInput &
                  Gender %in% input$GenderInput &
                 Style %in% input$StyleInput)
     
  ggplot(displayData,  aes(fill=SocialGroup, y=Formant, x=Gender)) + 
            geom_bar(position=position_dodge(), stat="identity") +
            facet_wrap(Style ~ .) +
         scale_y_continuous(limits=c(0,2), breaks=seq(0,2,.5)) + 
            labs(x="Gender", y = "Normed F2", title = "Lateral Velarization in Catalonian Spanish")
    }    else {
            displayData = DataName %>%
        filter(SocialGroup %in% input$SocialGroupInput &
                 Gender %in% input$GenderInput &
                 Style %in% input$StyleInput)
      
      ggplot(displayData,  aes(Formant, colour = SocialGroup)) + 
      scale_x_continuous(limits=c(0,2), breaks=seq(0,2,0.5)) + facet_grid(Style ~ .) + geom_density() + 
        labs(title = "Lateral Velarization in Catalonian Spanish")
    }
    })
}
shinyApp(ui = ui, server = server)
